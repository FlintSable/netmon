<a name="readme-top"></a>

<!-- ABOUT THE PROJECT -->

## About The Project

This is a start to a network monitoring terminal application.

Here's what works and doesn't:

- Menu is partially working
- Montoring is not working
- Creating a new instance of server is working

I need to continue working on this project as I was not able to get to the actual networking code because i'm stuck with the menu items.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- USAGE EXAMPLES -->

## Usage

python3 main.py

<p align="right">(<a href="#readme-top">back to top</a>)</p>
